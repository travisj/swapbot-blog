<?php
/**
 * @package Parament
 */
?>

</div><!-- end page-wrap -->
<footer id="colophon" role="contentinfo">
	<div id="site-generator">
		<a href="http://wordpress.org/" rel="generator">Proudly powered by WordPress</a>
		<?php printf( __( 'Theme: %1$s by %2$s.', 'parament' ), 'Parament', '<a href="http://automattic.com/" rel="designer">Automattic</a>' ); ?>
	</div>
</footer>

<?php wp_footer(); ?>

</body>
</html>