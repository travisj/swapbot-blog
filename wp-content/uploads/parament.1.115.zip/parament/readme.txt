Colors
======

The following colors are used throughout Parament:

Orange
------

	- #d24d04 - Dateline fill and important text.
	- #ff5a00 - Dateline border.


Blue
----

	- #202228 - For "off-black" backgrounds.
	- #33353d - Border colors.
	- #444855 - Border colors.
	- #666c7f - Not-so-important text color.
	- #777d92 - Footer text.
	- #989eae - Main text color.
	- #cccfd7 - Brighter Text.
	- #eaecef - Almost white.
